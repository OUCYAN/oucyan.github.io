﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.IO.Compression;
using System.IO;

namespace GameEngine_Launcher
{
    class Patcher
    {
        private Form1 form;
        private string path = "./Products/";
        private string zipName = "GameEngine.zip";
        private string fileName = "GameEngine";
        public void Patch(Form1 form)
        {
            this.form = form;
            WebClient wc = new WebClient();
            
                
                wc.DownloadProgressChanged += ReadProgress;
                wc.DownloadDataCompleted += UnpackFile;
                wc.DownloadFileAsync(
                    // URL
                    new System.Uri("https://oucyan.github.io/downloads/GameEngine.zip"),
                    // Save Path
                    path + zipName
                    ); 
            
            
        }

        private void ReadProgress(object sender, DownloadProgressChangedEventArgs e)
        {form.Debug(""+e.ProgressPercentage);
            form.SetDownloadProgress(e.ProgressPercentage);          
        }

        private void UnpackFile(object sender, DownloadDataCompletedEventArgs e)
        {
            form.SetPatchProgress(10);
            //Directory.Delete(path + fileName);
            form.SetPatchProgress(20);
            ZipFile.CreateFromDirectory(path, zipName);
            form.SetPatchProgress(40);
            ZipFile.ExtractToDirectory(zipName, path);
            form.SetPatchProgress(60);
            //File.Delete(path + zipName);
            form.SetPatchProgress(100);
        }
    }
}
