﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameEngine_Launcher
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LaunchButton.Enabled = false;
        }

        public void SetDownloadProgress(int progress)
        {
            
            DownloadBar.Value = progress;
        }
        public void SetPatchProgress(int progress)
        {
            PatchBar.Value = progress;
            if (progress == 100) LaunchButton.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Patcher patcher = new Patcher();
            patcher.Patch(this);
        }

        public void Debug(string message)
        {
            DebugLabel.Text = message;
        }
    }
}
